 How to Run
   1. Backend:
   1     cd server
   2     npm start
      (Ensure MongoDB is running locally or update .env).
   2. Frontend:
      Open client/public/index.html in your browser.

  The project is now ready for further development of the specific dashboards and additional API
  endpoints.